/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;



/**
 *
 * @author Profe
 */
public class HayDay {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // a) Cree 1 lista de animales con 2 gallinas y 1 vaca 
        
        
        // b) y 3 productos de animales disponibles (2 huevos; 1 leche)
        
        
       
        // c) Inicia la vista y controlador

    }
    
}
