/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author Profe
 */
public class Animal {
    //-------------------------------------------------
    // Atributos
    //-------------------------------------------------
    private ArrayList<ProductoAnimal> produccion = new ArrayList<>();
    private TipoAnimal tipo;
    private int capacidadProduccion = 1;
    private int pienso = 1;
    private int precio = 1;


    
    //-------------------------------------------------
    // Constructores
    //-------------------------------------------------

    
    

    //-------------------------------------------------
    // Getters & Setters
    //-------------------------------------------------
    
    
    

    //-------------------------------------------------
    // Funcionalidades
    //-------------------------------------------------
    public boolean puedeProducir(){
        
    }
    
    public void producir(){
        if(puedeProducir()){
            
        }
    }
    
    public ArrayList<ProductoAnimal> recolectar(){
        
    }   
    
    
    public boolean estaProduciendo(){
        
    }
}
