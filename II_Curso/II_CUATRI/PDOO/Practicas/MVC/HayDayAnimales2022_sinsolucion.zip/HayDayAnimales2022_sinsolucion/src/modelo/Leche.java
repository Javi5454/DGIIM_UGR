/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Profe
 */
public class Leche extends ProductoAnimal{
    //-------------------------------------------------
    // Atributos
    //-------------------------------------------------
    public static final String ICONO = "/img/leche40.png";
    
    //-------------------------------------------------
    // Constructores
    //-------------------------------------------------
    
    
    //-------------------------------------------------
    // Getters & Setters
    //-------------------------------------------------    

    //-------------------------------------------------
    // Funcionalidades
    //-------------------------------------------------

   
}
