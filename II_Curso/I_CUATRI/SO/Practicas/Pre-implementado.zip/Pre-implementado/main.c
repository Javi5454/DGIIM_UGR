/*
    SOLEDAD RUIZ GÓMEZ 2ºDGIIM
    
    EXAMEN PRÁCTICAS SISTEMAS OPERATIVOS MÓDULO II

    21 DICIEMBRE 2021

    EJERCICIO

*/

#include <sys/types.h>	
#include <sys/stat.h>	
#include <sys/wait.h>	
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <fcntl.h>

#define TAM 256 

int main(int argc, char *argv[]) {

// COMPROBACIÓN DE ARGUMENTOS

    // Número de argumentos
    if (argc != ) {
		perror ("\nNúmero de argumentos incorrecto\n\n");
		exit (EXIT_FAILURE);
	}

    //--


// EJECUCIÓN FUNCIONAL DEL PROGRAMA




    exit (EXIT_SUCCESS);
}