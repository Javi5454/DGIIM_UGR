var searchData=
[
  ['sudoku_5fkiller_5',['Sudoku_Killer',['../classSudoku__Killer.html',1,'']]]
];
