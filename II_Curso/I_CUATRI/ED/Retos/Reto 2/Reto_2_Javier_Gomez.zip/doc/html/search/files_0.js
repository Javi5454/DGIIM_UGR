var searchData=
[
  ['sudoku_5fkiller_2eh_6',['sudoku_killer.h',['../sudoku__killer_8h.html',1,'']]]
];
