var searchData=
[
  ['solvesudoku_8',['solveSudoku',['../classSudoku__Killer.html#a224d79734c75b3e9a3438ca5748244a3',1,'Sudoku_Killer']]],
  ['sudoku_5fkiller_9',['Sudoku_Killer',['../classSudoku__Killer.html#a4c2abc4471fabf41962595c200692671',1,'Sudoku_Killer']]]
];
