var searchData=
[
  ['representación_20del_20tda_20sudoku_5fkiller_2e_1',['Representación del TDA Sudoku_Killer.',['../repSudokuKiller.html',1,'']]]
];
