# OUTCOME OF TESTS FOR PROJECT shopping2_s

As of May 10 2021 17:40:36

| ID | NAME | RESULT | COMMENTS |
| :----- |:------ | :---: | :---: |
| 1::1 | _01_Basics.DateTime_Constructors | PASSED | OK |
| 1::2 | _01_Basics.DateTime_Constructors | PASSED | OK |
| 2::1 | _01_Basics.DateTime_getters | PASSED | OK |
| 2::2 | _01_Basics.DateTime_getters | PASSED | OK |
| 2::3 | _01_Basics.DateTime_getters | PASSED | OK |
| 2::4 | _01_Basics.DateTime_getters | PASSED | OK |
| 2::5 | _01_Basics.DateTime_getters | PASSED | OK |
| 2::6 | _01_Basics.DateTime_getters | PASSED | OK |
| 3::1 | _01_Basics.DateTime_set | PASSED | OK |
| 4::1 | _01_Basics.DateTime_sameDay | PASSED | OK |
| 4::2 | _01_Basics.DateTime_sameDay | PASSED | OK |
| 5::1 | _01_Basics.Event_ConstructorBase | PASSED | OK |
| 5::2 | _01_Basics.Event_ConstructorBase | PASSED | OK |
| 6::1 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 6::2 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 6::3 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 6::4 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 6::5 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 6::6 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 6::7 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 7::1 | _01_Basics.EventSet_Constructor | PASSED | OK |
| 7::2 | _01_Basics.EventSet_Constructor | PASSED | OK |
| 8::1 | _01_Basics.EventSet_add_event | PASSED | OK |
| 8::2 | _01_Basics.EventSet_add_event | PASSED | OK |
| 8::3 | _01_Basics.EventSet_add_event | PASSED | OK |
| 9::1 | _01_Basics.EventSet_add_line | PASSED | OK |
| 9::2 | _01_Basics.EventSet_add_line | PASSED | OK |
| 9::3 | _01_Basics.EventSet_add_line | PASSED | OK |
| 10::1 | _01_Basics.EventSet_at_basic | PASSED | OK |
| 10::2 | _01_Basics.EventSet_at_basic | PASSED | OK |
| 11::1 | _01_Basics.Pair_Constructors | PASSED | OK |
| 11::2 | _01_Basics.Pair_Constructors | PASSED | OK |
| 11::3 | _01_Basics.Pair_Constructors | PASSED | OK |
| 12::1 | _01_Basics.Pair_isEmpty | PASSED | OK |
| 12::2 | _01_Basics.Pair_isEmpty | PASSED | OK |
| 13::1 | _01_Basics.Pair_setters | PASSED | OK |
| 13::2 | _01_Basics.Pair_setters | PASSED | OK |
| 13::3 | _01_Basics.Pair_setters | PASSED | OK |
| 14::1 | _01_Basics.Pair_getters | PASSED | OK |
| 14::2 | _01_Basics.Pair_getters | PASSED | OK |
| 14::3 | _01_Basics.Pair_getters | PASSED | OK |
| 14::4 | _01_Basics.Pair_getters | PASSED | OK |
| 15::1 | _01_Basics.Index_Constructors | PASSED | OK |
| 15::2 | _01_Basics.Index_Constructors | PASSED | OK |
| 16::1 | _01_Basics.Index_getIOnWhich | PASSED | OK |
| 16::2 | _01_Basics.Index_getIOnWhich | PASSED | OK |
| 17::1 | _01_Basics.Index_clear | PASSED | OK |
| 17::2 | _01_Basics.Index_clear | PASSED | OK |
| 18::1| _01_Basics.Integrated_5_records-valgrind | PASSED | NO LEAKS |
| 18::1 | _01_Basics.Integrated_5_records | PASSED | OK |
| 18::2 | _01_Basics.Integrated_5_records | PASSED | OK |
| 19::1| _01_Basics.Integrated_30_records-valgrind | PASSED | NO LEAKS |
| 19::1 | _01_Basics.Integrated_30_records | PASSED | OK |
| 20::1| _01_Basics.Integrated_41_records-valgrind** | **FAILED** | **HAS MEMORY LEAKS** (!) |
| 21::1| **_01_Basics.Integrated_162_records** | **SKIPPED** | **The previous test failed** |
| 22::1| **_01_Basics.Integrated_926_records** | **SKIPPED** | **The previous test failed** |
| 23::1| **_01_Basics.Integrated_Args_5_records** | **SKIPPED** | **The previous test failed** |
| 24::1| **_01_Basics.Integrated_Args_30_records** | **SKIPPED** | **The previous test failed** |
| 25::1| **_01_Basics.Integrated_Args_41_records** | **SKIPPED** | **The previous test failed** |
| 26::1| **_01_Basics.Integrated_Args_162_records** | **SKIPPED** | **The previous test failed** |
| 27::1| **_01_Basics.Integrated_Args_926_records** | **SKIPPED** | **The previous test failed** |
| 28::1| **_02_Intermediate.DateTime_isBefore** | **SKIPPED** | **The previous test failed** |
| 29::1| **_02_Intermediate.DateTime_weekDay** | **SKIPPED** | **The previous test failed** |
| 30::1| **_02_Intermediate.Event_getField** | **SKIPPED** | **The previous test failed** |
| 31::1| **_02_Intermediate.EventSet_add_event_partial** | **SKIPPED** | **The previous test failed** |
| 32::1| **_02_Intermediate.EventSet_at_intermediate** | **SKIPPED** | **The previous test failed** |
| 33::1| **_02_Intermediate.Index_3x3_just_build** | **SKIPPED** | **The previous test failed** |
| 34::1| **_02_Intermediate.Index_B_BxU_build_at** | **SKIPPED** | **The previous test failed** |
| 35::1| **_02_Intermediate.Index_U_BxU_build_at** | **SKIPPED** | **The previous test failed** |
| 36::1| **_02_Intermediate.Integrated_EMPTY** | **SKIPPED** | **The previous test failed** |
| 37::1| **_02_Intermediate.Integrated_ErrorLoading** | **SKIPPED** | **The previous test failed** |
| 38::1| **_03_Advanced.DateTime_BadValues** | **SKIPPED** | **The previous test failed** |
| 39::1| **_03_Advanced.Event_setType_Bad_Values** | **SKIPPED** | **The previous test failed** |
| 40::1| **_03_Advanced.Event_Others_Bad_Values** | **SKIPPED** | **The previous test failed** |
| 41::1| **_03_Advanced.EventSet_add_event_full** | **SKIPPED** | **The previous test failed** |
| 42::1| **_03_Advanced.EventSet_at_advanced** | **SKIPPED** | **The previous test failed** |
| 43::1| **_03_Advanced.EventSet_externalfunctions** | **SKIPPED** | **The previous test failed** |
| 44::1| **_03_Advanced.EventSet_write** | **SKIPPED** | **The previous test failed** |
| 45::1| **_03_Advanced.EventSet_read** | **SKIPPED** | **The previous test failed** |
| 46::1 | _03_Advanced.Index_U_BxU_bounds | PASSED | OK |
| 46::2 | _03_Advanced.Index_U_BxU_bounds | PASSED | OK |
| 47::1 | _03_Advanced.Index_B_BxU_bounds | PASSED | OK |
| 47::2 | _03_Advanced.Index_B_BxU_bounds | PASSED | OK |
| 48::1 | _03_Advanced.Index_add | PASSED | OK |
| 48::2 | _03_Advanced.Index_add | PASSED | OK |
| 48::3 | _03_Advanced.Index_add | PASSED | OK |
| 49::1 | _03_Advanced.Index_B_BxU_rawFilterIndex | PASSED | OK |
| 50::1 | _03_Advanced.Index_U_BxU_rawFilterIndex | PASSED | OK |
| 51::1 | _03_Advanced.Index_Type_BxU_rawFilterIndex | PASSED | OK |
| 52::1 | _03_Advanced.Index_DateTime_BxU_rawFilterIndex | PASSED | OK |
| 53::1 | _03_Advanced.Index_BxU_sumPrice | PASSED | OK |
| 53::2 | _03_Advanced.Index_BxU_sumPrice | PASSED | OK |
| 53::3 | _03_Advanced.Index_BxU_sumPrice | PASSED | OK |
| 53::4 | _03_Advanced.Index_BxU_sumPrice | PASSED | OK |
| 54::1| **_03_Advanced.Integrated_ErrorData** | **SKIPPED** | **The previous test failed** |
| 55::1| **_03_Advanced.Integrated_ErrorSaving** | **SKIPPED** | **The previous test failed** |
| 56::1| **_03_Advanced.Integrated_Args_no_open** | **SKIPPED** | **The previous test failed** |
| 57::1| **_03_Advanced.Integrated_Args_error_data** | **SKIPPED** | **The previous test failed** |
| 58::1| **_03_Advanced.Integrated_Args_error_missing_arg** | **SKIPPED** | **The previous test failed** |
| 59::1| **_03_Advanced.Integrated_Args_error_bad_arg** | **SKIPPED** | **The previous test failed** |

(!)  SIMPLIFIED MEMORY LEAK REPORT BY Valgrind Mon 10 May 2021 05:43:38 PM CEST

   * **Process terminating with default action of signal 2 (SIGINT)**

   * **Process terminating with default action of signal 11 (SIGSEGV)**