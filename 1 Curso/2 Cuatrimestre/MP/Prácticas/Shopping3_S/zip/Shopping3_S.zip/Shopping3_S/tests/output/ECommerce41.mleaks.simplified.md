# SIMPLIFIED MEMORY LEAK REPORT BY Valgrind 

Mon 10 May 2021 05:43:38 PM CEST


1. **Process terminating with default action of signal 2 (SIGINT)**
1. **Process terminating with default action of signal 11 (SIGSEGV)**
