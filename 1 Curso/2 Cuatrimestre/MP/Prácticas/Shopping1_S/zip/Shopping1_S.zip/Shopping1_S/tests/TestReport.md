# OUTCOME OF TESTS FOR PROJECT shopping1_s

As of Apr 15 2021 12:47:41

| ID | NAME | RESULT | COMMENTS |
| :----- |:------ | :---: | :---: |
| 1::1 | _01_Basics.DateTime_Constructors | PASSED | OK |
| 1::2 | _01_Basics.DateTime_Constructors | PASSED | OK |
| 2::1 | _01_Basics.DateTime_getters | PASSED | OK |
| 2::2 | _01_Basics.DateTime_getters | PASSED | OK |
| 2::3 | _01_Basics.DateTime_getters | PASSED | OK |
| 2::4 | _01_Basics.DateTime_getters | PASSED | OK |
| 2::5 | _01_Basics.DateTime_getters | PASSED | OK |
| 2::6 | _01_Basics.DateTime_getters | PASSED | OK |
| 3::1 | _01_Basics.DateTime_set | PASSED | OK |
| 4::1 | _01_Basics.Event_ConstructorBase | PASSED | OK |
| 4::2 | _01_Basics.Event_ConstructorBase | PASSED | OK |
| 5::1 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 5::2 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 5::3 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 5::4 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 5::5 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 5::6 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 5::7 | _01_Basics.Event_Setters_getters | PASSED | OK |
| 6::1| _01_Basics.Integration_ECommerce5-valgrind | PASSED | NO LEAKS |
| 6::1 | _01_Basics.Integration_ECommerce5 | PASSED | OK |
| 7::1| _01_Basics.Integration_EMPTY-valgrind | PASSED | NO LEAKS |
| 7::1 | _01_Basics.Integration_EMPTY | PASSED | OK |
| 8::1| _01_Basics.Integration_ECommerce49-valgrind | PASSED | NO LEAKS |
| 8::1 | _01_Basics.Integration_ECommerce49 | PASSED | OK |
| 9::1| _01_Basics.Integration_ECommerce_2019_Q4_200-valgrind | PASSED | NO LEAKS |
| 9::1 | _01_Basics.Integration_ECommerce_2019_Q4_200 | PASSED | OK |
| 10::1| _01_Basics.Integration_ECommerce_all_all_200-valgrind | PASSED | NO LEAKS |
| 10::1 | _01_Basics.Integration_ECommerce_all_all_200 | PASSED | OK |
| 11::1 | _02_Intermediate.DateTime_isBefore | PASSED | OK |
| 11::2 | _02_Intermediate.DateTime_isBefore | PASSED | OK |
| 11::3 | _02_Intermediate.DateTime_isBefore | PASSED | OK |
| 12::1 | _02_Intermediate.DateTime_weekDay | PASSED | OK |
| 12::2 | _02_Intermediate.DateTime_weekDay | PASSED | OK |
| 12::3 | _02_Intermediate.DateTime_weekDay | PASSED | OK |
| 13::1 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::2 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::3 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::4 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::5 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::6 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::7 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::8 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::9 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 13::10 | _03_Advanced.DateTime_BadValues | PASSED | OK |
| 14::1 | _03_Advanced.Event_setType_Bad_Values | PASSED | OK |
| 14::2 | _03_Advanced.Event_setType_Bad_Values | PASSED | OK |
| 15::1 | _03_Advanced.Event_Others_Bad_Values | PASSED | OK |
| 15::2 | _03_Advanced.Event_Others_Bad_Values | PASSED | OK |
| 15::3 | _03_Advanced.Event_Others_Bad_Values | PASSED | OK |
